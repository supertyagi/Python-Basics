a=input("Enter state or Union Territory name")
if a=="Andhra Pradesh":
 print "capital=Hyderabad"
 print "STD code=040"
 print "population=49,386,799"
 print "decadal growth=11.1%"
 print "area=162,968 km square"
 print "sex ratio=993"
else: 
 print "not found"