a=int(input("enter the first digit"))
b=int(input("enter the second digit"))
for s in range(1,11):
 print a,"x",s,"=",a*s,("  "),b,"x",s,"=",b*s