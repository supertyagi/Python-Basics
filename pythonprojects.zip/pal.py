n=int(input("enter any no"))
str(n) == str(n)[::-1]