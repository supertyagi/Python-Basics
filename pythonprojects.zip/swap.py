print "Swap the values of a and b".center(80)
a=input("Enter anything in a:")
b=input("Enter anything in b:")
print "the swap value of a is",b
print "the swap value of b is",a