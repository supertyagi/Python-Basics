num1=5
num2=6
print num1+num2