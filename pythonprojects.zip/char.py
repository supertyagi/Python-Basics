first=input("first character")
second=input("second character")
print str(first)+(" ")+str(second)