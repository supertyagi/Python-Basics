for s in range(1,11):
 print "2x",s,"=",s*2