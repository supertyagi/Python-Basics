print "You will get a random no between 0 to 101".center(80)
import random
print random.randint(0,101)