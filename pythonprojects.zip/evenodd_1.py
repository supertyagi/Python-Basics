a=int(input("enter the digit"))
if(a%2==0):
 print "even"
else:
 print "odd"