print"How many days in a month".center(80) 
month=input("enter the name of month:")
if month=="january":
 print month+" has 31 days"
elif month=="march":
 print month+" has 31 days"
elif month=="may":
 print month+" has 31 days"
elif month=="july":
 print month+" has 31 days"
elif month=="august":
 print month+" has 31 days"
elif month=="october":
 print month+" has 31 days"
elif month=="december":
 print month+" has 31 days"
elif month=="february":
 print month+" has 28 days in a common year and 29 days in a leap year"
elif month=="":
 print month+" has 31 days"
elif month=="june":
 print month+" has 30 days"
elif month=="september":
 print month+" has 30 days"
elif month=="november":
 print month+" has 30 days"
else:
 print "month name ",month," not found "