a=int(input("enter the digit"))
for s in range(1,11):
 print a,"x",s,"=",s*a