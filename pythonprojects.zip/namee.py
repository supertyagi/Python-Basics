name=input("what is your name")
print name