a=float(input("enter marks of physics"))
b=float(input("enter marks of chemistry"))
c=float(input("enter marks of maths"))
total=a+b+c
av=total/3
per=(total/300)*100
print av,"is your average score",(" "),per,"%","is your total percentage"