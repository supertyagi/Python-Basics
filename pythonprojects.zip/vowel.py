a=input("enter the alphabet")
if a=="a" or a=="e" or a=="i" or a=="o" or a=="u":
 print "the alphabet is vowel"
else:
 print "the alphabet is consonant"