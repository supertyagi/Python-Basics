print "CHECK PRIME NUMBER".center(80)
a=int(input("Enter the number:"))
if (a%2!=0):
 print a,"is a prime number" 
elif a==2:
 print a,"is a prime number"
else:
 print "PLEASE ENTER AN INTEGER".center(80)