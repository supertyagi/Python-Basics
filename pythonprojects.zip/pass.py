import getpass
mypass = getpass.getpass("Please enter your password:")