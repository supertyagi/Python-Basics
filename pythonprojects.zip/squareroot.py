print "Find the Square Root".center(80)
a=float(input("Enter Your No:"))
print a**0.5