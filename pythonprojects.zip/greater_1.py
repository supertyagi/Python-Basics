a=int(input("enter first digit"))
b=int(input("enter second digit"))
if a>b:
 print a,"is greater"
else:
 print b,"is greater"