print "age calculator"
birth_year=int(input("enter your birth year:"))
i=0
for i in (1900,2017):
 age=2017-birth_year
 print "you are",(""),age,(""),"years old"
 break

 