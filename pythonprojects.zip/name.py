name=input("enter your name")
 print name