a=input("your word in double quotes")
b=input("your second word in double quotes")
print str(a)+(" ")+str(b)