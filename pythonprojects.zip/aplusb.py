a=int(input("Enter first no:"))
b=int(input("Enter second no:"))
print a+b