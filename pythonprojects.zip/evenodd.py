print "CHECK YOUR NUMBER IS ODD OR EVEN ?".center(80)
a=float(input("Enter the number:"))
if (a%2==0):
 print a,"is even number"
elif (a%2!=0):
 print a,"is odd number"
else:
 print "PLEASE ENTER A NUMBER"