num1=4
num2=7
print num1-num2