for s in range(1,101):
 if(s%2!=0):
  print s