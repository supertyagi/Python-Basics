function getVelocity(h,range) 
{
   //Complete this
   return 16000;

 function getAngle(h,range)}
{
   //Complete this
   return 45;
 }
 
 velocity = getVelocity();

angle = getAngle();
 kickBall(velocity,angle);
      